
import pandas as pd

# Create sample trigram data
trigrams = pd.DataFrame({
    "word1": ["i", "you", "we"],
    "word2": ["am", "are", "are"],
    "word3": ["happy", "tired", "ready"],
    "n": [100, 80, 50]
})

# Create sample bigram data
bigrams = pd.DataFrame({
    "word1": ["i", "you", "we"],
    "word2": ["love", "are", "will"],
    "n": [150, 120, 70]
})

# Save as .rds placeholders (pickle format)
trigrams.to_pickle("../trigrams.rds")
bigrams.to_pickle("../bigrams.rds")
